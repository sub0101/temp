package dto

type ResponseGetLibrary struct {
	ID   uint   `json:"id,omitempty"`
	Name string `json:"name"`
}
