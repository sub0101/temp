package dto

import "libraryManagement/internal/models"

type ResponseBookInfo struct {
	Title     string `json:"title"`
	Isbn      string `json:"isbn"`
	Authors   string `json:"authors"`
	Publisher string `json:"publisher"`
	Version   string `json:"version"`
}

type RequestUpdateBook struct {
	Title           string `json:"title"`
	Isbn            string `json:"isbn"`
	Authors         string `json:"authors"`
	Publisher       string `json:"publisher"`
	Version         string `json:"version"`
	TotalCopies     uint   `json:"totalCopies"`
	AvailableCopies uint   `json:"availableCopies"`
}

type SearchBookPayload struct {
	Title     string `json:"title"`
	Author    string `json:"author"`
	Publisher string `json:"publisher"`
}

type IssuedBooks struct {
	models.IssueRegistery
	Book struct {
		Name string
	}
}
