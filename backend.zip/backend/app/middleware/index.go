package middleware

import (
	"fmt"
	"libraryManagement/utility"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
)

func IsAuth(roles ...string) gin.HandlerFunc {

	return func(c *gin.Context) {
		fmt.Println("middlerware")
		// fmt.Println(c.Request.Header.Get("authorization"))
		authorizationHeader := strings.Split(c.Request.Header.Get("authorization"), " ")
		if len(authorizationHeader) <= 1 && len(authorizationHeader) < 2 {
			utility.SendResponse(c, 400, false, "Bad Request", nil, fmt.Errorf("Invalid Token").Error())
			c.Abort()
		}
		fmt.Println(authorizationHeader)
		authorizationHeader[0] = ""
		fmt.Println(len(authorizationHeader))
		token := authorizationHeader[1]
		jwtToken, err := utility.VerifyToken(token)
		if err != nil {
			utility.SendResponse(c, 401, false, "Unauthorized", nil, err.Error())
			c.Abort()
		}
		claims, _ := jwtToken.Claims.(jwt.MapClaims)
		payload := claims["payload"].(map[string]interface{})
		
		role := payload["Role"]
		userId := payload["Id"]
		libId := payload["LibId"]

		fmt.Println(userId)
		c.Set("id", userId)
		c.Set("libId", libId)

		isInclude := len(roles) == 0

		for _, r := range roles {

			if r == role {

				isInclude = true
				break
			}
		}
		if !isInclude {
			utility.SendResponse(c, http.StatusForbidden, false, "Page Not Found", nil)
			c.Abort()
		}
	}

}
