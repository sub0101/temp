package book

import (
	"fmt"
	auth "libraryManagement/app/modules/Auth"
	"libraryManagement/internal/dto"
	"libraryManagement/internal/models"

	"github.com/jinzhu/copier"
	"gorm.io/gorm"
)

type BookService struct {
	db *gorm.DB
}

var book models.BookInventory
var response dto.ResponseBookInfo
var user *models.User

func (bookService *BookService) AddBook(userId, libId uint, book models.BookInventory) error {

	db := bookService.db

	if err := db.Where("ID = ? AND lib_id = ?", userId, libId).First(&user).Error; err != nil {
		return fmt.Errorf("User does not exist in the current library")
	}

	if book.AvailableCopies != book.TotalCopies {
		return fmt.Errorf("total available copies must be equal to total Copies ")
	}

	var oldBook models.BookInventory
	isExist := db.Where("isbn=? AND lib_id=?", book.ISBN, book.LibID).First(&oldBook)
	if err := isExist.Error; err == nil {
		oldBook.TotalCopies += book.TotalCopies
		oldBook.AvailableCopies += book.AvailableCopies

		updatedResult := db.Where("ID = ?", oldBook.ID).Updates(&models.BookInventory{TotalCopies: oldBook.TotalCopies, AvailableCopies: oldBook.AvailableCopies})
		return updatedResult.Error
	}
	book.LibID = libId
	if err := db.Create(&book).Error; err != nil {
		return fmt.Errorf("Failed to Add Book : %s", err.Error())
	}

	return nil
}

func (bookService *BookService) GetAllBook(userId uint, libId uint) ([]map[string]interface{}, error) {
	// var books []models.BookInventory
	var books []map[string]interface{}
	db := bookService.db
	var user models.User

	if err := auth.IsLibraryAdmin(db, libId, userId); err != nil {
		return nil, err
	}
	if err := db.Where("id=? AND lib_id=?", userId, libId).First(&user).Error; err != nil {

		return nil, fmt.Errorf("can not find user")
	}

	if user.Role == "reader" {
		if err := db.Model(&models.BookInventory{}).Omit("total_copies", "available_copies", "lib_id", "CreatedAt", "DeletedAt", "UpdatedAt").
			Where("lib_id = ?", libId).Find(&books).Error; err != nil {
			return nil, err
		}
		return books, nil
	}

	bookResult := db.Model(&models.BookInventory{}).Where("lib_id = ?", libId).Find(&books)

	return books, bookResult.Error
}

func (bookService *BookService) GetBook(id uint) (*dto.ResponseBookInfo, error) {

	db := bookService.db

	db.Where("ID = ?", id).Find(&book)
	if err := copier.Copy(&response, &book); err != nil {
		return nil, err
	}
	return &response, nil

}

func (bookService *BookService) UpdateBook(userId, bookId uint, updatedBook dto.RequestUpdateBook) error {
	DB := bookService.db
	fmt.Println("update book service")
	var book models.BookInventory
	if err := DB.Where("id =? ", bookId).First(&book); err.Error != nil {
		fmt.Println(err.Error)
		return err.Error
	}

	if err := auth.IsLibraryAdmin(DB, book.LibID, userId); err != nil {
		fmt.Println(err)
		return err
	}
	if err := copier.Copy(&book, &updatedBook); err != nil {
		fmt.Println(err)

		return fmt.Errorf("Not able convert ")
	}

	if err := DB.Where("id = ?", bookId).Updates(&book); err.Error != nil {
		fmt.Println(err)
		return err.Error
	}
	fmt.Println("book is updated")
	fmt.Println(book)
	return nil

}
func (bookService *BookService) DeleteBook(bookId, userId uint) error {
	DB := bookService.db
	if result := DB.Where("id =? ", bookId).First(&book); result.Error != nil {
		fmt.Println(result.Error)
		return fmt.Errorf("Book does not exist")
	}
	if err := auth.IsLibraryAdmin(DB, book.LibID, userId); err != nil {
		return err
	}
	if result := DB.Where("id=?", bookId).Select("TotalCopies", "AvailableCopies").Updates(&models.BookInventory{TotalCopies: 0, AvailableCopies: 0}); result.Error != nil {
		fmt.Println(result.Error)
		return result.Error
	}

	return nil

}

func (bookService *BookService) GetIssuedBook(readerId uint, libId uint) ([]dto.IssuedBooks, error) {
	// DB := bookService.db
	// var allIssued []models.IssueRegistery
	// DB.Where("reader_id = ?", readerId).Find(&allIssued)
	// return
	// var issuedBooks []models.BookInventory
	// DB.Where("lib_id =?", libId).Find(&issuedBooks)

	// var issueRequests []models.IssueRegistery

	// if err := DB.Where("reader_id=?", readerId).Find(&issueRequests).Error; err != nil {
	// 	return nil, err
	// }

	// var temp = make(map[string]string)

	// for _, item := range issuedBooks {
	// 	temp[item.ISBN] = item.Title
	// }
	// var response []dto.IssuedBooks
	// fmt.Println(issueRequests)
	// copier.Copy(&response, &issueRequests)
	// for _, item := range response {
	// 	item.Book.Name = temp[item.ISBN]
	// }
	// return response, nil
	return nil, nil
}

func (bookService *BookService) SearchBook(libId uint, payload *dto.SearchBookPayload) ([]models.BookInventory, error) {

	db := bookService.db
	var searchedBooks []models.BookInventory

	result := db.Where("lib_id=? AND (authors = ? OR title = ? OR publisher = ?)", libId, payload.Author, payload.Title, payload.Publisher).Find(&searchedBooks)
	if result.Error != nil {
		return nil, result.Error
	}
	return searchedBooks, nil
}
