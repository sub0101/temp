package issueregistery

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

type IssueRegistryController struct {
	issueService *IssueRegistryService
}

func NewIssueRegistryController(db *gorm.DB) *IssueRegistryController {

	service := IssueRegistryService{DB: db}
	return &IssueRegistryController{issueService: &service}
}

func (ic *IssueRegistryController) GetAllIssue(c *gin.Context) {

}
func (ic *IssueRegistryController) GetIssue(c *gin.Context) {

}
