package issueregistery

import (
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

func IssueRegistryRouter(router *gin.RouterGroup, db *gorm.DB) {

	issueController := NewIssueRegistryController(db)

	IssueRouter := router.Group("/issueRegister")
	{

		IssueRouter.GET("/", issueController.GetAllIssue)
		IssueRouter.GET("/:id", issueController.GetIssue)
	}

}
