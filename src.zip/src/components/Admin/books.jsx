"use client"

import { useState } from "react"
import styles from "../../style/books.module.css"

function Books() {
  const [books, setBooks] = useState([
    {
      id: 1,
      title: "To Kill a Mockingbird",
      author: "Harper Lee",
      category: "Fiction",
      isbn: "9780061120084",
      publishYear: 1960,
      available: true,
      copies: 3,
    },
    {
      id: 2,
      title: "1984",
      author: "George Orwell",
      category: "Science Fiction",
      isbn: "9780451524935",
      publishYear: 1949,
      available: true,
      copies: 5,
    },
    {
      id: 3,
      title: "The Great Gatsby",
      author: "F. Scott Fitzgerald",
      category: "Fiction",
      isbn: "9780743273565",
      publishYear: 1925,
      available: false,
      copies: 2,
    },
    {
      id: 4,
      title: "Pride and Prejudice",
      author: "Jane Austen",
      category: "Romance",
      isbn: "9780141439518",
      publishYear: 1813,
      available: true,
      copies: 4,
    },
    {
      id: 5,
      title: "The Hobbit",
      author: "J.R.R. Tolkien",
      category: "Fantasy",
      isbn: "9780547928227",
      publishYear: 1937,
      available: true,
      copies: 3,
    },
    {
      id: 6,
      title: "The Catcher in the Rye",
      author: "J.D. Salinger",
      category: "Fiction",
      isbn: "9780316769488",
      publishYear: 1951,
      available: false,
      copies: 1,
    },
  ])

  const [searchTerm, setSearchTerm] = useState("")
  const [filter, setFilter] = useState("all")

  const filteredBooks = books.filter((book) => {
    const matchesSearch =
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase())

    if (filter === "all") return matchesSearch
    if (filter === "available") return matchesSearch && book.available
    if (filter === "issued") return matchesSearch && !book.available

    return matchesSearch
  })

  return (
    <div className={styles.booksPage}>
      <div className={styles.pageHeader}>
        <h1 className={styles.pageTitle}>Book Management</h1>
        <button className={styles.addButton}>Add New Book</button>
      </div>

      <div className={styles.filterContainer}>
        <div className={styles.searchContainer}>
          <input
            type="text"
            className={styles.searchInput}
            placeholder="Search books by title or author..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className={styles.filterItem}>
          <span className={styles.filterLabel}>Status:</span>
          <select className={styles.filterSelect} value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">All Books</option>
            <option value="available">Available</option>
            <option value="issued">Issued</option>
          </select>
        </div>
      </div>

      <div className={styles.bookGrid}>
        {filteredBooks.map((book) => (
          <div className={styles.bookCard} key={book.id}>
            <div className={styles.bookCover}>
              <span>Book Cover</span>
            </div>
            <div className={styles.bookDetails}>
              <h3 className={styles.bookTitle}>{book.title}</h3>
              <p className={styles.bookAuthor}>by {book.author}</p>
              <div className={styles.bookMeta}>
                <span>Category: {book.category}</span>
                <span>Year: {book.publishYear}</span>
              </div>
              <div className={styles.bookMeta}>
                <span>ISBN: {book.isbn}</span>
                <span className={`${styles.badge} ${book.available ? styles.badgeSuccess : styles.badgeDanger}`}>
                  {book.available ? "Available" : "Issued"}
                </span>
              </div>
              <div className={styles.bookMeta}>
                <span>Copies: {book.copies}</span>
              </div>
              <div className={styles.actionButtons}>
                <button className={styles.editButton}>Edit</button>
                <button className={styles.deleteButton}>Delete</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Books

 