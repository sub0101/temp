import styles from "../../style/dashboard.module.css"

function Dashboard() {
  return (
    <div className={styles.dashboard}>
      <h1 className={styles.pageTitle}>Dashboard</h1>

      <div className={styles.statsContainer}>
        <div className={`${styles.statCard} ${styles.books}`}>
          <h3>Total Books</h3>
          <div className={styles.statValue}>1,250</div>
        </div>

        <div className={`${styles.statCard} ${styles.available}`}>
          <h3>Available Books</h3>
          <div className={styles.statValue}>1,100</div>
        </div>

        <div className={`${styles.statCard} ${styles.issued}`}>
          <h3>Issued Books</h3>
          <div className={styles.statValue}>150</div>
        </div>

        <div className={`${styles.statCard} ${styles.users}`}>
          <h3>Total Users</h3>
          <div className={styles.statValue}>320</div>
        </div>
      </div>

      <div className={styles.recentActivities}>
        <h2>Recent Activities</h2>
        <div className={styles.tableContainer}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Activity</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>John Doe borrowed "The Great Gatsby"</td>
                <td>2023-06-15</td>
              </tr>
              <tr>
                <td>Jane Smith returned "To Kill a Mockingbird"</td>
                <td>2023-06-14</td>
              </tr>
              <tr>
                <td>New book added: "The Catcher in the Rye"</td>
                <td>2023-06-13</td>
              </tr>
              <tr>
                <td>New user registered: Robert Johnson</td>
                <td>2023-06-12</td>
              </tr>
              <tr>
                <td>Emily Davis borrowed "1984"</td>
                <td>2023-06-11</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

export default Dashboard

