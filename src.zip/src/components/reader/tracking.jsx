import styles from "../../style/requeststracking.module.css"

function RequestTracking() {
  const requests = [
    { id: 1, title: "To Kill a Mockingbird", status: "Pending", type: "Issue" },
    { id: 2, title: "1984", status: "Approved", type: "Return" },
    { id: 3, title: "Pride and Prejudice", status: "Rejected", type: "Issue" },
  ]

  return (
    <div className={styles.requestTracking}>
      <h1>Request Tracking</h1>
      <table className={styles.requestTable}>
        <thead>
          <tr>
            <th>Book Title</th>
            <th>Request Type</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {requests.map((request) => (
            <tr key={request.id}>
              <td>{request.title}</td>
              <td>
                <span className={`${styles.requestType} ${styles[request.type.toLowerCase()]}`}>
                  {request.type}
                </span>
              </td>
              <td>
                <span className={`${styles.status} ${styles[request.status.toLowerCase()]}`}>
                  {request.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default RequestTracking
