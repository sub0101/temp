import React from 'react';

const Contactus = () => {
    return (
        <div>
        this is contact us
        </div>
    );
}

export default Contactus;
